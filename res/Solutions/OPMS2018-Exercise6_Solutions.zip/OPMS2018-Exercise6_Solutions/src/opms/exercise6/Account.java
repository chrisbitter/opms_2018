package opms.exercise6;

public class Account {
	
	private int pin;
	private double balance = 0;
	
	
	public Account(int pin, double balance) {
		this.pin = pin;
		this.balance = balance;
	}
		
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double newBalance) {
		balance = newBalance;
	}
	
	public boolean pinIsValid(int pin) {
		return pin == this.pin;
	}
}
