package opms.exercise6;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ATM {

	public static void main(String[] args) {
		Map<Integer, Account> accounts = new HashMap<>();

		accounts.put(1234, new Account(1234, 205.3));
		accounts.put(5678, new Account(5678, 11.4));
		accounts.put(4321, new Account(4321, 10.5));

		Scanner reader = new Scanner(System.in);
		int userInput1 = reader.nextInt();
		double userInput2 = reader.nextDouble();
		
		System.out.println("Insert Card");

		int card_number = reader.nextInt();

		if (accounts.containsKey(card_number)) {

			Account account = accounts.get(card_number);

			boolean pinIsValid = false;

			for (int trial = 0; trial < 3; trial++) {

				System.out.println("Enter Pin");
				int pin = reader.nextInt();

				if (account.pinIsValid(pin)) {
					pinIsValid = true;
					break;
				}
			}

			if (pinIsValid) {

				System.out.println("You have " + account.getBalance() + " Euros");

				System.out.println("Enter amount");
				double requestedFunds = reader.nextDouble();

				if (requestedFunds <= account.getBalance()) {
					account.setBalance(account.getBalance() - requestedFunds);
					System.out.println("Withdrawing " + requestedFunds + " Euros");
				} else {
					System.out.println("Insufficient funds");
				}
			}
		}
		System.out.println("Returning Card");
		reader.close();
	}
}
