
public class PlasticBottle extends Bottle {

}
