
public class GlassBottle extends Bottle {

}
