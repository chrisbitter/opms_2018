
public class VacuumRobot extends Robot {
	
}
