package opms.exercise3;

public class GlassBottle extends Bottle {

}
