package opms.exercise3;

public class TestRecycler {
	public static void main(String[] args) {
		Recycler recycler = new Recycler();
		
		GlassBottle bottle1 = new GlassBottle();
		GlassBottle bottle2 = new GlassBottle();
		PlasticBottle bottle3 = new PlasticBottle();

		recycler.insert(bottle1);
		recycler.insert(bottle2);
		recycler.insert(bottle3);
	}
}
