package opms.exercise3;

public class Robot {

	public void speak() {
		System.out.println("beep beep");
	}
}
