package opms.exercise3.shapes;

import java.awt.Color;

public class Rectangle extends AbstractShape {

	public Rectangle(Point lowerLeft, Point upperRight, Color color, boolean filled) {
		this(lowerLeft.getX(), lowerLeft.getY(), upperRight.getX(), upperRight.getY(), color, filled);
	}
	
	public Rectangle(int x1, int y1, int x2, int y2, Color color, boolean filled) {
		addPoint(new Point(x1,y1));
		addPoint(new Point(x1,y2));
		addPoint(new Point(x2,y2));
		addPoint(new Point(x2,y1));
		setColor(color);
		setFilled(filled);
	}
	
}
