package opms.exercise3.shapes;

import java.awt.Color;
import java.util.List;

public class Polygon extends AbstractShape {

	public Polygon(List<Point> points, Color color, boolean filled) {
		for (Point p : points) {
			addPoint(p);
		}
		setColor(color);
		setFilled(filled);
	}
	
}
