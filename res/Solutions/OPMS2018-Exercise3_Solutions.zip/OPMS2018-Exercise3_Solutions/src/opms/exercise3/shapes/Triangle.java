package opms.exercise3.shapes;

import java.awt.Color;

public class Triangle extends AbstractShape {

	public Triangle(Point p1, Point p2, Point p3, Color color, boolean filled) {
		addPoints(p1, p2, p3);
		setColor(color);
		setFilled(filled);
	}
	
}
