package opms.exercise3;

public class TestRobot {
	public static void main(String[] args) {
		Robot robot1 = new Robot();
		robot1.speak();
		
		VacuumRobot robot2 = new VacuumRobot();
		robot2.speak();
		
		HumaniodRobot robot3 = new HumaniodRobot();
		robot3.speak();
		
		HumaniodRobot robot4 = new HumaniodRobot("WALL-E");
		robot4.speak();
		
	}
}
