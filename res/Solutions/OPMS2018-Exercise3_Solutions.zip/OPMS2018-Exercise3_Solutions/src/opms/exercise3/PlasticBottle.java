package opms.exercise3;

public class PlasticBottle extends Bottle {

}
