package opms.exercise3;

public class Car {
	private int speed = 100;
	
	public int getSpeed() {
		return speed;
	}
	
	public void decelerate() {
		speed = speed - 20;
	}
	
	public void accelerate() {
		speed = speed + 15;
	}
}
