package opms.exercise3;


public class Bottle {

}
