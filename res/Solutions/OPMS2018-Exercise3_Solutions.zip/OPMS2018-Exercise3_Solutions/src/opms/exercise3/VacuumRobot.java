package opms.exercise3;

public class VacuumRobot extends Robot {
	
}
