package opms.exercise3;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import opms.exercise3.shapes.Point;
import opms.exercise3.shapes.Polygon;
import opms.exercise3.shapes.Rectangle;
import opms.exercise3.shapes.Shape;
import opms.exercise3.shapes.Triangle;

public class Application {

	public static void main(String[] args) {
		
		// a list of shapes that have to be drawn
		List<Shape> shapes = new ArrayList<>();
		shapes.add(new Rectangle(75, 100, 225, 225, Color.ORANGE, true));
		shapes.add(new Triangle(new Point(50,100), new Point(250,100), new Point(150, 50), Color.BLUE, true));
		
		// create a list of points for our polygon
		List<Point> points = new ArrayList<Point>();
		points.add(new Point(125, 225));
		points.add(new Point(175, 225));
		points.add(new Point(175, 200));
		points.add(new Point(150, 180));
		points.add(new Point(125, 200));
		shapes.add(new Polygon(points, Color.RED, true));
		
		// create the frame and draw the shapes
		ShapeFrame frame = new ShapeFrame();
		frame.setVisible(true);
		frame.drawShapes(shapes);
	}

}
