
public class Recycler {
	public void insert(GlassBottle bottle) {
		System.out.println("I don't accept glass bottles");
	}
	
	public void insert(PlasticBottle bottle) {
		System.out.println("Thank you!");
	}
}
