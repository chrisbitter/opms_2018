
public class HumaniodRobot extends Robot {
	private String name;
	
	public HumaniodRobot() {
		this.name = "C3PO";
	}
	
	public HumaniodRobot(String name) {
		this.name = name;
	}	
	
	public void speak() {
		System.out.println("Hello. My name is " +name);
	}

}
