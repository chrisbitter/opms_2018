
public class CarTest {
	public static void main(String[] args) {
		Car car = new Car();
		
		car.accelerate();
		car.accelerate();
		
		car.decelerate();
		car.decelerate();
		car.decelerate();
		
		System.out.println(car.getSpeed());
	}
}