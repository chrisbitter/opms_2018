package opms.exercise2;

public class Task6 {

	public static void main(String[] args) {

		int[] fib_numbers = new int[10];

		for (int i = 0; i < 10; i++) {

			int fib_number = fibonacci(i);

			System.out.println(i + " " + fib_number);

			fib_numbers[i] = fib_number;
		}
	}

	public static int fibonacci(int n) {
		if (n == 0)
			return 0;
		else if (n == 1)
			return 1;
		else {

			int a = 0;
			int b = 1;
			int tmp;

			for (int i = 1; i < n; i++) {
				tmp = b;
				b = a + b;
				a = tmp;
			}
			return b;
		}
	}

	public static int fibonacci_recursive(int n) {
		if (n == 0)
			return 0;
		else if (n == 1)
			return 1;
		else
			return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2);
	}
}
