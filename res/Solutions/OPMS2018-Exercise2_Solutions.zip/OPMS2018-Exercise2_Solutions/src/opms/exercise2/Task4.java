package opms.exercise2;

public class Task4 {

	public static void main(String[] args) {
		for (int i = 0; i < 1000; i++) {
			if (i % 2 > 0) {
				System.out.print(i + ",");
			}
			if (i > 0 && i % 20 == 0) {
				System.out.println("");
			}
		}
	}
}
