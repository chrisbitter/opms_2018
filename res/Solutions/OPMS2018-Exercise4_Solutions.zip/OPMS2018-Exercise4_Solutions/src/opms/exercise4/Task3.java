package opms.exercise4;
import java.util.ArrayList;

public class Task3 {
	
	public static void main(String[] args) {
		ArrayList<String> students = new ArrayList<>();
		
		students.add("Johannes");
		
		students.add("Alex");
		students.add("Andreas");
		
		System.out.println(students.toString());
		
		students.add(1, "WALL-E");
		System.out.println(students.toString());
		
		students.remove("Johannes");
		System.out.println(students.toString());
		
		students.clear();
		System.out.println(students.toString());
	}
}
