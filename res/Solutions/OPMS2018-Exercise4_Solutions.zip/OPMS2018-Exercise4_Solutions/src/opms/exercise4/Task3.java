package opms.exercise4;

import java.util.HashMap;
import java.util.LinkedList;

public class Task3 {
	
	public static void main(String[] args) {
		HashMap<String, Integer> stock = new HashMap<>();
		
		stock.put("Rubber Duck", 1);
		stock.put("Watch", 4);
		stock.put("Camera", 2);
		stock.put("Skateboard", 1);
		
		for (String article : stock.keySet()) {
			System.out.println(article + ": " + stock.get(article) + " left.");
		}
		
		LinkedList<String> orders = new LinkedList<>();
		
		orders.add("Camera");
		orders.add("Skateboard");
		orders.add("DVD");
		orders.add("Skateboard");
		
		for (String order : orders) {
			if (stock.containsKey(order)) {
				
				int amtLeft = stock.get(order);
				
				if (amtLeft > 0) {
					stock.put(order, amtLeft - 1);
					System.out.println("Order " + order + " fulfilled.");
				} else {
					System.out.println("No articles " + order + " left.");
				}
			} else {
				System.out.println("Unknown article " + order);
			}
		}
	}
}
