package opms.exercise4;

public class MathFunctions {
	public static void main(String[] args) {

		// Task 1
		for (int a = 0; a < 5; a += 2) {
			for (int b = 0; b < 5; b += 2) {

				double x = (double) a;
				double y = (double) b;

				try {
					System.out.println(x + " / " + y + " = " + division(x, y));
				} catch (DivisionByZeroException e) {
					System.out.println(x + " / " + y + " -> " + e.getMessage());
				}
			}
		}

		// Task 2
		try {
			System.out.println(arctan(0, 0));
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}

	}

	public static double division(double x, double y) throws DivisionByZeroException {
		if (y == 0) {
			throw new DivisionByZeroException("Tried to divide by zero!");
		} else {
			return x / y;
		}
	}

	public static double arctan(double x, double y) throws IllegalArgumentException {

		if (x > 0) {
			return Math.atan(y / x);
		} else if (x < 0) {
			if (y > 0) {
				return Math.atan(y / x) + Math.PI;
			} else if (y < 0) {
				return Math.atan(y / x) + Math.PI;
			} else {
				return Math.PI;
			}
		} else {
			if (y > 0) {
				return Math.PI / 2;
			} else if (y < 0) {
				return -Math.PI / 2;
			} else {
				throw new IllegalArgumentException("x and y cannot both be 0 at the same time.");
			}
		}
	}

}
