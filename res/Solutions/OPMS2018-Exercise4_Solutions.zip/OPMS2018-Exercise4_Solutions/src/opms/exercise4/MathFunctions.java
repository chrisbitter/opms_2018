package opms.exercise4;


public class MathFunctions {
	public static void main(String[] args) {


		// Task 2
		try {
			System.out.println(getPolarAngle(20, 5.5));
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}

	}

	public static double division(double x, double y) throws DivisionByZeroException {
		if (y == 0) {
			throw new DivisionByZeroException("Tried to divide by zero!");
		} else {
			return x / y;
		}
	}

	public static double getPolarAngle(double x, double y) throws IllegalArgumentException {

		if (x > 0) {
			return Math.atan(y / x);
		} else if (x < 0) {
			if (y > 0) {
				return Math.atan(y / x) + Math.PI;
			} else if (y < 0) {
				return Math.atan(y / x) + Math.PI;
			} else {
				return Math.PI;
			}
		} else {
			if (y > 0) {
				return Math.PI / 2;
			} else if (y < 0) {
				return -Math.PI / 2;
			} else {
				throw new IllegalArgumentException("x and y cannot both be 0 at the same time.");
			}
		}
	}

}
