package opms.exercise5;

public class AutomatedWarehouse {

	public static void main(String[] args) {
		/*
		Pallet pallet1 = new Pallet(2018);
		System.out.println("Serial number is: " +pallet1);
		
		ConveyorBelt conveyorBelt = new ConveyorBelt();
		
		Pallet pallet2 = new Pallet(42);
		Pallet pallet3 = new Pallet(2020);
		
		conveyorBelt.loadPallet(pallet1);
		conveyorBelt.loadPallet(pallet2);
		conveyorBelt.loadPallet(pallet3);
		
		System.out.println("All pallets are: " +conveyorBelt.getPallets());
		*/
		
		
		/*
		Pallet[] palletSlots = new Pallet[10];
		
		Pallet pallet1 = new Pallet(541201);
		Pallet pallet2 = new Pallet(541202);
		Pallet pallet3 = new Pallet(663319);
		Pallet pallet4 = new Pallet(663325);
		Pallet pallet5 = new Pallet(909042);
		
		palletSlots[1] = pallet1;		
		palletSlots[2] = pallet2;		
		palletSlots[5] = pallet3;		
		palletSlots[6] = pallet4;		
		palletSlots[9] = pallet5;
		
		ConveyorBelt conveyorBelt = new ConveyorBelt();
		Forklift forklift = new Forklift(palletSlots, conveyorBelt);
		*/
		
		/*
		try {
			forklift.moveTo(2);
			System.out.println("Sees pallet: " +forklift.seesPallet());
			forklift.moveTo(7);
			System.out.println("Sees pallet: " +forklift.seesPallet());
			forklift.moveTo(-11);
		} catch (ForkliftOutOfBoundsException e) {
			System.out.println("Out of bounds");
		}
		*/

		/*
		try {
			forklift.moveTo(1);
			forklift.liftPallet();
			forklift.placeOnBelt();
			
			forklift.moveTo(5);
			forklift.liftPallet();
			forklift.placeOnBelt();
			
			System.out.println("Loaded pallets: " +conveyorBelt.getPallets());
		} catch (ForkliftOutOfBoundsException e) {
			System.out.println("Out of bounds");
		}
		*/
		
		
		//////////////////////////////////
		// Add the code for task 7 here //
		//////////////////////////////////
		
	}
}