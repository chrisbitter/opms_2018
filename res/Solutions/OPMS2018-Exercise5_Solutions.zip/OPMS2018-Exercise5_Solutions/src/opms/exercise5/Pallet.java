package opms.exercise5;

public class Pallet {
	private int serialNumber;
	
	public Pallet(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public int getSerialNumber() {
		return this.serialNumber;
	}
	
	public String toString() {
		return Integer.toString(this.serialNumber);
	}
}
