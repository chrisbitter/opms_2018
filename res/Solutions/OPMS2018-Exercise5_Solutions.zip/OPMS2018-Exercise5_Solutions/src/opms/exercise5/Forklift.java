package opms.exercise5;

public class Forklift {
	private Pallet[] palletSlots;
	private ConveyorBelt conveyorBelt;
	private int position;
	private Pallet currentPallet;
	
	public Forklift(Pallet[] palletSlots, ConveyorBelt conveyorBelt) {
		this.palletSlots = palletSlots;
		this.conveyorBelt = conveyorBelt;
	}
	
	public void moveTo(int position) throws ForkliftOutOfBoundsException {
		if (position < 0 || position > 9) {
			throw new ForkliftOutOfBoundsException();
		}
		this.position = position;
	}
	
	public boolean seesPallet() {
		if(palletSlots[position] == null) {
			return false;
		} else {
			return true;
		}
	}
	
	public void liftPallet() {
		this.currentPallet = palletSlots[position];
		palletSlots[position] = null;
	}
	
	public void placeOnBelt() throws ForkliftOutOfBoundsException {
		this.moveTo(0);
		conveyorBelt.loadPallet(this.currentPallet);
		currentPallet = null;
	}
}
