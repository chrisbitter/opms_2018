package opms.exercise5;

import java.util.ArrayList;
import java.util.List;

public class ConveyorBelt {
	private List<Pallet> pallets = new ArrayList<>();
	
	public void loadPallet(Pallet pallet) {
		this.pallets.add(pallet);
	}
	
	public List<Pallet> getPallets() {
		return this.pallets;
	}
}
