package opms.exercise5;

public class ForkliftOutOfBoundsException extends Exception {

}
