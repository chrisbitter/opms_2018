package opms.exercise1;

public class Task2 {

	public static void main(String[] args) {
		int x = 2;
		int y = 5;
		int z = x + y;
		System.out.println("The sum of x (" + x + ") and y (" + y + ") is " + z);				
		
	}
	
}
