package opms.exercise3.base;

import java.util.ArrayList;
import java.util.List;

import opms.exercise3.shapes.Shape;

public class Application {

	public static void main(String[] args) {
		
		// a list of shapes that have to be drawn
		List<Shape> shapes = new ArrayList<>();

		// create the frame and draw the shapes
		ShapeFrame frame = new ShapeFrame();
		frame.drawShapes(shapes);
		frame.setVisible(true);
	}

}
