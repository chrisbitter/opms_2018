package opms.final_project;

import lejos.nxt.*;

public class Sensor {

	private static final int THRESHOLD_RED = 450;
	private static final int THRESHOLD_BLUE = 280;
	private static final int THRESHOLD_DISTANCE = 14;

	private UltrasonicSensor sonic = new UltrasonicSensor(SensorPort.S1);
	// Task 3.2

	public Sensor() {

	}

	public boolean ballPresent() {
		return sonic.getDistance() < THRESHOLD_DISTANCE;
	}

	// Task 3.3 - 3.4

}
