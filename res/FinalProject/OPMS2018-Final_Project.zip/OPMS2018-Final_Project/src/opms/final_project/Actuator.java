package opms.final_project;

import lejos.nxt.Motor;

public class Actuator {

	private static final int GRIPPER_OPEN = 0;
	private static final int GRIPPER_CLOSED = 100;

	private static final int PITCH_MOVE = -60;
	private static final int PITCH_GRAB = -87;

	// Task 2.5
	private static final double TRANSMISSION_ROTATION = 1;
	private static final double TRANSMISSION_PITCH = 5.0;
	private static final double TRANSMISSION_GRIPPER = 1.0;

	public Actuator() {

	}

	public void toMovePitch() {
		Motor.B.rotateTo((int) (PITCH_MOVE * TRANSMISSION_PITCH));
	}

	public void toGrabPitch() {
		Motor.B.rotateTo((int) (PITCH_GRAB * TRANSMISSION_PITCH));
	}

	public void openGripper() {
		Motor.A.rotateTo((int) (GRIPPER_OPEN * TRANSMISSION_GRIPPER));
	}

	public void closeGripper() {
		Motor.A.rotateTo((int) (GRIPPER_CLOSED * TRANSMISSION_GRIPPER));
	}

	// Task 6.1

	// Task 2.2 - 2.4
}
