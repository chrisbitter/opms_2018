package opms.final_project;

import lejos.nxt.*;
import pa_tools.Tools;

public class Robot {
	Sensor sensor = new Sensor();
	Actuator actuator = new Actuator();

	public Robot() {
		Tools.calibrateAll();
		actuator.toMovePitch();
	}

	// Task 5
	// Task 6.2 - 6.3

	// Task 4

}
