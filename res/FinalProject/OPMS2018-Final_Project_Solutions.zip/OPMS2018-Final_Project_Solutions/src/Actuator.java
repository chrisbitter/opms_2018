import lejos.nxt.Motor;

public class Actuator {

	private static final int GRIPPER_OPEN = 0;
	private static final int GRIPPER_CLOSED = 100;

	private static final int PITCH_MOVE = -60;
	private static final int PITCH_GRAB = -87;

	// Task 2d
	private static final double TRANSMISSION_ROTATION = 6.875;
	private static final double TRANSMISSION_PITCH = 5.0;
	private static final double TRANSMISSION_GRIPPER = 1.0;

	public Actuator() {

	}

	public void toMovePitch() {
		Motor.B.rotateTo((int) (PITCH_MOVE * TRANSMISSION_PITCH));
	}

	public void toGrabPitch() {
		Motor.B.rotateTo((int) (PITCH_GRAB * TRANSMISSION_PITCH));
	}

	public void openGripper() {
		Motor.A.rotateTo((int) (GRIPPER_OPEN * TRANSMISSION_GRIPPER));
	}

	public void closeGripper() {
		Motor.A.rotateTo((int) (GRIPPER_CLOSED * TRANSMISSION_GRIPPER));
	}

	// Task 6a
	public void moveToCheckRing(int ring) {
		if (ring < 0 || ring > 2) {
			throw new IndexOutOfBoundsException("Ring ID should be between 0 and 2");
		}

		int angle = (int) (((ring - 1) * 45 - 20) * TRANSMISSION_ROTATION);

		Motor.C.rotateTo(angle);
	}

	public void moveAboveRing(int ring) {
		// Task 2a
		if (ring < 0 || ring > 2) {
			throw new IndexOutOfBoundsException("Ring ID should be between 0 and 2");
		}

		// Task 2b
		int angle = (int) ((ring - 1) * 45 * TRANSMISSION_ROTATION);

		// Task 2c
		Motor.C.rotateTo(angle);
	}
}
