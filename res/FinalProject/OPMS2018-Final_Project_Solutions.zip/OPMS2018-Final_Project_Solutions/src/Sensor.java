import lejos.nxt.*;

public class Sensor {

	private static final int THRESHOLD_RED = 350;
	private static final int THRESHOLD_DISTANCE = 14;

	private UltrasonicSensor sonic = new UltrasonicSensor(SensorPort.S1);
	// Task 3a
	private LightSensor light = new LightSensor(SensorPort.S4);
		
	
	public Sensor() {

	}

	public boolean ballPresent() {
		return sonic.getDistance() < THRESHOLD_DISTANCE;
	}

	// Task 3b
	public String getColor() {
		if (light.readNormalizedValue() > THRESHOLD_RED) {
			return "RED";
		} else {
			return "BLUE";
		}
	}

}
