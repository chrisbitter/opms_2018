import lejos.nxt.Button;

// Task 1

public class Testing {
	
	public static void main(String[] args) {
		
		
		
		// Task 2
		Actuator actuator = new Actuator();
		actuator.moveAboveRing(0);
		actuator.moveAboveRing(1);
		actuator.moveAboveRing(2);
		
		// Task 3
		Sensor sensor = new Sensor();
		System.out.println(sensor.getColor());
		
		// Task 4
		Robot robot = new Robot();
		robot.moveBall(0, 1);
		
		// Task 5
		try {
			robot.run();			
		} catch (AllRingsOccupiedException e) {
			System.out.println("Abort procedure because all rings are occupied.");
		}
		
		// Task 6
		actuator.moveToCheckRing(0);
		System.out.println(sensor.ballPresent());
		
		Button.waitForAnyPress();

	}
}
