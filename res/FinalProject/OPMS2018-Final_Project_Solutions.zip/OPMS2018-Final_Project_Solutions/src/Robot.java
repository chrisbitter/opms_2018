import lejos.nxt.*;
import pa_tools.Tools;

public class Robot {
	Sensor sensor = new Sensor();
	Actuator actuator = new Actuator();

	public Robot() {
		Tools.calibrateAll();
		actuator.toMovePitch();
	}

	public void run() throws AllRingsOccupiedException {

		int empty_position = -1;

		// Task 6b
		for (int ring = 0; ring < 3; ring++) {

			actuator.moveToCheckRing(ring);

			if (!sensor.ballPresent()) {
				empty_position = ring;
			}
		}

		// Task 6c
		if (empty_position != -1) {

			System.out.println(empty_position);

			// Task 5
			for (int move = 0; move < 3; move++) {
				int from = (empty_position + move + 1) % 3;
				int to = (from + 2) % 3;
				moveBall(from, to);
			}
			
			// Task 7 - Inspiration
			actuator.moveAboveRing((empty_position + 1) % 3);

		} else {
			throw new AllRingsOccupiedException();
		}

	}

	public void moveBall(int from, int to) {

		// Task 4a
		actuator.moveAboveRing(from);
		actuator.openGripper();
		actuator.toGrabPitch();
		actuator.closeGripper();

		// Task 4b
		System.out.println(sensor.getColor());

		// Task 4c
		actuator.toMovePitch();
		actuator.moveAboveRing(to);
		actuator.toGrabPitch();
		actuator.openGripper();
		actuator.toMovePitch();

	}

}
