
public class AllRingsOccupiedException extends Exception {

}
